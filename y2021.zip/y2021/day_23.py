import heapq
from collections import defaultdict, namedtuple

from aocd_tools import load_input_data
from itertools import count
EXAMPLE = """
#############
#...........#
###B#C#B#D###
  #A#D#C#A#
  #########
"""

# diagram
"""
#############
#01.2.3.4.56#
###1#3#5#7###
  #0#2#4#6#
  #########
"""

"""
  0 1 2 3 4 5 6 
0 4 3 3 5 7 9 A
1 3 2 2 5 7 9 A
2 6 5 3 3 5 7 8
3 5 4 2 2 4 6 7
4 8 7 5 3 3 5 6 
5 7 6 4 2 2 4 5
6 A 9 7 5 3 3 4
7 9 8 6 4 4 2 3
"""

DISTANCES = """
4 3 3 5 7 9 A
3 2 2 5 7 9 A
6 5 3 3 5 7 8
5 4 2 2 4 6 7
8 7 5 3 3 5 6 
7 6 4 2 2 4 5
A 9 7 5 3 3 4
9 8 6 4 4 2 3
""".strip()

seqnum = count()

distances = [
    [int(v, 16) for v in line.split()]
    for line in DISTANCES.split("\n")
]

HALLWAY_COUNT = 7
ROOM_COUNT = 8
Amphipod = namedtuple("amphipod", "start_pos energy rooms")


def distance(room, hallway):
    return distances[room][hallway]


def cost(amphipod, room, hallway):
    return distance(room, hallway) * amphipod.energy


def parse(line):
    return line


def run():
    lines = [
        Amphipod(0, 1, [0, 1]),  # A
        Amphipod(6, 1, [0, 1]),  # A
        Amphipod(1, 10, [2, 3]),  # B
        Amphipod(5, 10, [2, 3]),  # B
        Amphipod(3, 100, [4, 5]),  # C
        Amphipod(4, 100, [4, 5]),  # C
        Amphipod(7, 1000, [6, 7]),  # D
        Amphipod(2, 1000, [6, 7]),  # D
    ]
    print("solution1 = ", solution1(lines))
    print("solution2 = ", solution2(lines))


def solution1(amphipods):
    amphipods.sort(key=lambda x: x.start_pos)
    gameboard = (
        [None] * HALLWAY_COUNT,
        [n for n in range(8)]
    )

    queue = []
    heapq.heappush(queue, (0, next(seqnum), gameboard))
    best_solution = 10000000

    while queue:
        energy, _, gameboard = heapq.heappop(queue)
        hallway, rooms = gameboard
        if complete(rooms, amphipods):
            best_solution = min(best_solution, energy)
            continue

        for hallway_idx, apidx in enumerate(hallway):
            if apidx is None:
                continue
            amphipod = amphipods[apidx]
            # can only move to empty room
            for room_idx in amphipod.rooms:
                if can_move_to_room(rooms, room_idx, amphipod, amphipods):
                    print(f"R{room_idx}")
                    new_board = (hallway.copy(), rooms.copy())
                    new_board[0][hallway_idx] = None
                    new_board[1][room_idx] = apidx
                    e = energy + cost(amphipod, room_idx, hallway_idx)
                    print(f"Move h{hallway_idx}->r{room_idx} e={e}")
                    heapq.heappush(queue, (e, next(seqnum), new_board))

        for room_idx, apidx in enumerate(rooms):
            if apidx is None: continue
            amphipod = amphipods[apidx]
            # can only move to empty hallway
            for hallway_idx in range(HALLWAY_COUNT):
                if hallway[hallway_idx] is None:
                    new_board = (hallway.copy(), rooms.copy())
                    new_board[0][hallway_idx] = apidx
                    new_board[1][room_idx] = None
                    e = energy + cost(amphipod, room_idx, hallway_idx)
                    # print(f"Move r{room_idx}->h{hallway_idx} e={e}")
                    heapq.heappush(queue, (e, next(seqnum), new_board))
    return None


def can_move_to_room(rooms, room_idx, amphipod, amphipods):
    if rooms[room_idx] != None:
        return False
    # odd rooms only accessible if valid amphipod in n-1
    if room_idx % 2:
        adj_ap = rooms[room_idx - 1]
        if adj_ap is None or amphipods[adj_ap].energy != amphipod.energy:
            return False


def complete(rooms, amphipods):
    for roomidx, apidx in enumerate(rooms):
        if apidx is None:
            return False
        amphipod = amphipods[apidx]
        if roomidx not in amphipod.rooms:
            return False
    return True


def solution2(lines):
    return None


if __name__ == "__main__":
    run()
