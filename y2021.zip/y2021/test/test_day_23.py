import unittest

from y2021.day_23 import distance


class TestDay23(unittest.TestCase):
    def test_distance(self):
        self.assertEqual(4, distance(0, 0))
        self.assertEqual(6, distance(4, 6))
        self.assertEqual(3, distance(6, 4))
        self.assertEqual(10, distance(6, 0))


if __name__ == '__main__':
    unittest.main()
