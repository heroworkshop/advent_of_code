import unittest


class TestDay19(unittest.TestCase):
    def test_something(self):
        self.assertFalse(1, 0)


if __name__ == '__main__':
    unittest.main()
